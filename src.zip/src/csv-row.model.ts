export interface CsvRow {
    Name: string;
    Email: string;
    'Phone number': string;
    City: string;
    Address: string;
    GPA: number;
  }
  
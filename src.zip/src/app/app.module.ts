import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule} from './app-routing.module';
import { AppComponent } from './app.component';
import { UploadComponent } from './upload/upload.component';
import { PreviewComponent } from './preview/preview.component';
import { SummaryComponent } from './summary/summary.component';
import { CsvService } from './csv.service';


@NgModule({
  declarations: [
    AppComponent,
    UploadComponent,
    PreviewComponent,
    SummaryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,

    
    
  ],
  providers: [CsvService],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component ,OnInit} from '@angular/core';
import { CsvService } from '../csv.service';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit{
  validRows: number = 0;
  invalidRows: number = 0;

  constructor(private csvService: CsvService) {}

  ngOnInit() {
    this.validRows = this.csvService.validRows;
    this.invalidRows = this.csvService.invalidRows;
  }
}

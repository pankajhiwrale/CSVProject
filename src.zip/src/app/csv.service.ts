import { Injectable } from '@angular/core';
import { Papa } from 'ngx-papaparse';
import { CsvRow } from '../csv-row.model';

@Injectable({
  providedIn: 'root'
})
export class CsvService {
  csvData: CsvRow[] = [];
  validRows: number = 0;
  invalidRows: number = 0;

  constructor(private papa: Papa) {}

  parseCsv(file: File) {
    return new Promise((resolve, reject) => {
      this.papa.parse(file, {
        complete: (result) => {
          // Convert GPA to number where necessary
          this.csvData = result.data.map((row: any) => ({
            Name: row.Name,
            Email: row.Email,
            'Phone number': row['Phone number'],
            City: row.City,
            Address: row.Address,
            GPA: parseFloat(row.GPA) // Convert GPA to number
          })) as CsvRow[];
          resolve(this.csvData);
        },
        header: true,
        skipEmptyLines: true
      });
    });
  }

  validateData(data: CsvRow[]): string[][] {
    const errors: string[][] = [];
    this.validRows = 0;
    this.invalidRows = 0;

    data.forEach((row, index) => {
      const rowErrors: string[] = [];
      if (!row.Name || typeof row.Name !== 'string') rowErrors.push('Name is invalid');
      if (!row.Email || !this.validateEmail(row.Email)) rowErrors.push('Email is invalid');
      if (!row['Phone number'] || !this.validatePhoneNumber(row['Phone number'])) rowErrors.push('Phone number is invalid');
      if (!row.City || typeof row.City !== 'string') rowErrors.push('City is invalid');
      if (!row.Address || typeof row.Address !== 'string') rowErrors.push('Address is invalid');
      if (isNaN(row.GPA) || row.GPA < 0 || row.GPA > 10) rowErrors.push('GPA is invalid'); // row.GPA is already a number
      errors.push(rowErrors);
      if (rowErrors.length === 0) this.validRows++;
      else this.invalidRows++;
    });

    return errors;
  }

  private validateEmail(email: string): boolean {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  private validatePhoneNumber(phone: string): boolean {
    const re = /^\d{10}$/;
    return re.test(phone);
  }
}
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CsvService } from '../csv.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent {
  constructor(private csvService: CsvService, private router: Router) {}

  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    if (file) {
      this.csvService.parseCsv(file).then(() => {
        this.router.navigate(['/preview']);
      });
    }
  }
}

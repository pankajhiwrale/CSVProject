import { Component, OnInit } from '@angular/core';
import { CsvService } from '../csv.service';
import { Router } from '@angular/router';
import { CsvRow } from 'src/csv-row.model';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})
export class PreviewComponent implements OnInit{

  csvData: CsvRow[] = [];
  errors: string[][] = [];

  constructor(private csvService: CsvService, private router: Router) {}

  ngOnInit() {
    this.csvData = this.csvService.csvData;
    this.errors = this.csvService.validateData(this.csvData);
  }

  proceedToSummary() {
    this.router.navigate(['/summary']);
  }

}
